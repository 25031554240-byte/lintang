import customtkinter as ctk
from tkinter import ttk, messagebox
from tkcalendar import Calendar
import json, os
from PIL import Image
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# Konfigurasi awal CustomTkinter
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

# File penyimpanan data
USER_FILE = "users.json"
TRANSACTION_FILE = lambda user: f"{user}_transaksi.json"

# Fungsi utilitas untuk data
def load_users():
    try:
        return json.load(open(USER_FILE, "r")) if os.path.exists(USER_FILE) else {}
    except:
        return {}

def save_users(data):
    try:
        json.dump(data, open(USER_FILE, "w"), indent=4)
    except Exception as e:
        messagebox.showerror("Error", f"Gagal simpan user: {str(e)}")

def load_transactions(user):
    try:
        if os.path.exists(TRANSACTION_FILE(user)):
            return json.load(open(TRANSACTION_FILE(user), "r"))
        return []
    except:
        return []

def save_transactions(user, data):
    try:
        json.dump(data, open(TRANSACTION_FILE(user), "w"), indent=4)
    except Exception as e:
        messagebox.showerror("Error", f"Gagal simpan transaksi: {str(e)}")

# ================= SPLASH SCREEN =================
class SplashScreen(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.geometry("500x300")
        self.overrideredirect(True)
        self.configure(fg_color="#79AFFF")

        # Pengecekan logo aman
        try:
            logo_img = Image.open("logo_dakost.png")
        except FileNotFoundError:
            logo_img = Image.new("RGB", (200, 200), color="white")
        self.logo = ctk.CTkImage(logo_img, size=(200, 200))

        # Tampilan splash
        ctk.CTkLabel(self, image=self.logo, text="").pack(expand=True)
        ctk.CTkLabel(self, text="Loading...", font=("Tahoma", 16), text_color="white").pack(pady=10)

        # Pindah ke login setelah 2,5 detik
        self.after(3000, self.goto_login)

    def goto_login(self):
        self.destroy()
        app = LoginRegister()
        app.mainloop()

# ================= LOGIN & REGISTER =================
class LoginRegister(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.geometry("480x520")
        self.title("Login & Register")
        self.mode = "login"  # "login" atau "register"

        # Frame utama
        self.main_frame = ctk.CTkFrame(self, fg_color="#E3EEFF", corner_radius=16)
        self.main_frame.pack(expand=True, fill="both", padx=20, pady=20)

        # Bangun tampilan
        self.build_ui()

    def build_ui(self):
        # Hapus widget lama
        for widget in self.main_frame.winfo_children():
            widget.destroy()

        # Judul
        title = "LOGIN" if self.mode == "login" else "REGISTER"
        ctk.CTkLabel(self.main_frame, text=title, font=("Segoe UI", 26, "bold")).pack(pady=20)

        # Input username
        self.username_input = ctk.CTkEntry(self.main_frame, placeholder_text="Username", height=40)
        self.username_input.pack(padx=30, fill="x", pady=10)

        # Input password
        self.password_input = ctk.CTkEntry(self.main_frame, placeholder_text="Password", height=40, show="*")
        self.password_input.pack(padx=30, fill="x", pady=10)

        # Input konfirmasi password (hanya register)
        if self.mode == "register":
            self.confirm_pw_input = ctk.CTkEntry(self.main_frame, placeholder_text="Konfirmasi Password", height=40, show="*")
            self.confirm_pw_input.pack(padx=30, fill="x", pady=10)

        # Tombol utama (login/register)
        btn_text = "Login" if self.mode == "login" else "Register"
        btn_command = self.process_login if self.mode == "login" else self.process_register
        ctk.CTkButton(self.main_frame, text=btn_text, fg_color="#79AFFF", height=45, command=btn_command).pack(padx=30, fill="x", pady=15)

        # Tombol switch mode
        switch_text = "Belum punya akun? Register" if self.mode == "login" else "Sudah punya akun? Login"
        ctk.CTkButton(self.main_frame, text=switch_text, fg_color="#4CAF50", height=38, command=self.switch_mode).pack(padx=30, fill="x")

    def switch_mode(self):
        self.mode = "register" if self.mode == "login" else "login"
        self.build_ui()

    def process_login(self):
        username = self.username_input.get().strip()
        password = self.password_input.get().strip()

        # Validasi input kosong
        if not username or not password:
            messagebox.showwarning("Peringatan", "Isi username dan password!")
            return

        # Cek data user
        users = load_users()
        if username in users and users[username] == password:
            self.destroy()
            app = AplikasiKeuangan(username)
            app.mainloop()
        else:
            messagebox.showerror("Error", "Username atau password salah!")

    def process_register(self):
        username = self.username_input.get().strip()
        password = self.password_input.get().strip()
        confirm_pw = self.confirm_pw_input.get().strip()

        # Validasi input
        if not username or not password or not confirm_pw:
            messagebox.showwarning("Peringatan", "Isi semua kolom!")
            return
        if password != confirm_pw:
            messagebox.showerror("Error", "Password tidak cocok!")
            return

        # Simpan user baru
        users = load_users()
        if username in users:
            messagebox.showerror("Error", "Username sudah ada!")
            return
        users[username] = password
        save_users(users)
        messagebox.showinfo("Sukses", "Akun berhasil dibuat!")
        self.switch_mode()

# ================= APLIKASI KEUANGAN UTAMA =================
class AplikasiKeuangan(ctk.CTk):
    def __init__(self, username):
        super().__init__()
        self.username = username
        self.geometry("1400x800")  # Diperbesar untuk mengakomodasi kalender dan tabel
        self.title(f"Aplikasi Keuangan - {username}")

        # Data transaksi
        self.transactions = load_transactions(username)

        # Bangun antarmuka utama
        self.build_main_ui()

    def build_main_ui(self):
        # Frame menu kiri
        self.menu_frame = ctk.CTkFrame(self, width=230, fg_color="#CFE3FF")
        self.menu_frame.pack(side="left", fill="y", padx=5, pady=5)

        # Judul menu
        ctk.CTkLabel(self.menu_frame, text=f"Hi, {self.username}", font=("Segoe UI", 20, "bold")).pack(pady=20)

        # Tombol menu
        ctk.CTkButton(self.menu_frame, text="Dashboard", command=self.show_dashboard).pack(fill="x", padx=20, pady=10)
        ctk.CTkButton(self.menu_frame, text="Transaksi", command=self.show_transaksi).pack(fill="x", padx=20, pady=10)
        ctk.CTkButton(self.menu_frame, text="Simpan File", fg_color="#4CAF50", command=self.save_transaction_file).pack(fill="x", padx=20, pady=10)
        ctk.CTkButton(self.menu_frame, text="Logout", fg_color="#FF8A65", command=self.do_logout).pack(fill="x", padx=20, pady=10)

        # Frame konten utama (dengan scrollbar vertikal)
        self.content_frame = ctk.CTkScrollableFrame(self, fg_color="#F2F7FF")
        self.content_frame.pack(side="left", expand=True, fill="both", padx=5, pady=5)

        # Nama pembuat (atas kanan)
        ctk.CTkLabel(self, text="Dibuat oleh: nevin,maya,lintang", font=("Segoe UI", 12, "italic"), text_color="gray").place(relx=0.98, rely=0.02, anchor="ne")

        # Copyright (bawah)
        ctk.CTkLabel(self, text="© 2025 | Aplikasi Keuangan", font=("Segoe UI", 10), text_color="gray").pack(side="bottom", pady=5)

        # Tampilkan dashboard pertama kali
        self.show_dashboard()

    def clear_content(self):
        # Hapus semua widget di frame konten
        for widget in self.content_frame.winfo_children():
            widget.destroy()

    def show_dashboard(self):
        self.clear_content()

        # Judul dashboard
        ctk.CTkLabel(self.content_frame, text="Dashboard", font=("Segoe UI", 34, "bold")).pack(pady=30)
        ctk.CTkLabel(self.content_frame, text=f"Selamat datang, {self.username}", font=("Segoe UI", 20)).pack(pady=10)

        # Informasi aplikasi
        info_frame = ctk.CTkFrame(self.content_frame, fg_color="#E3EEFF", corner_radius=16)
        info_frame.pack(padx=40, pady=20, fill="x")
        ctk.CTkLabel(info_frame, text="Aplikasi ini digunakan untuk mencatat\npemasukan dan pengeluaran keuanganmu dengan mudah.", font=("Segoe UI", 16), justify="center").pack(pady=30)

        # Hitung total pemasukan, pengeluaran, dan saldo
        total_pemasukan = 0
        total_pengeluaran = 0
        for trans in self.transactions:
            nominal_str = trans[2].replace("Rp ", "").replace(",", "")
            nominal = float(nominal_str)
            if trans[3] == "Pemasukan":
                total_pemasukan += nominal
            elif trans[3] == "Pengeluaran":
                total_pengeluaran += nominal
        saldo = total_pemasukan - total_pengeluaran

        # Frame untuk total saldo
        saldo_frame = ctk.CTkFrame(self.content_frame, fg_color="#E3EEFF", corner_radius=16)
        saldo_frame.pack(padx=40, pady=20, fill="x")
        ctk.CTkLabel(saldo_frame, text=f"Total Saldo: Rp {saldo:,.0f}", font=("Segoe UI", 24, "bold"), text_color="green" if saldo >= 0 else "red").pack(pady=20)

        # Frame untuk diagram lingkaran
        chart_frame = ctk.CTkFrame(self.content_frame, fg_color="#E3EEFF", corner_radius=16)
        chart_frame.pack(padx=70, pady=30, fill="both", expand=True)

        # Buat diagram lingkaran menggunakan matplotlib
        fig, ax = plt.subplots(figsize=(15, 10))
        if total_pemasukan > 0 or total_pengeluaran > 0:
            ax.pie([total_pemasukan, total_pengeluaran], labels=["Pemasukan", "Pengeluaran"], autopct='%1.1f%%', startangle=90, colors=['#4CAF50', '#FF8A65'])
        else:
            ax.pie([1], labels=["Tidak ada data"], autopct='%1.1f%%', startangle=90, colors=['#CCCCCC'])
        ax.set_title("Distribusi Pemasukan vs Pengeluaran")

        # Embed ke Tkinter
        canvas = FigureCanvasTkAgg(fig, master=chart_frame)
        canvas.get_tk_widget().pack(fill="both", expand=True)
        canvas.draw()

    def show_transaksi(self):
        self.clear_content()

        # Frame form input
        form_frame = ctk.CTkFrame(self.content_frame, fg_color="#E3EEFF", corner_radius=16)
        form_frame.pack(fill="x", padx=40, pady=40)
        ctk.CTkLabel(form_frame, text="Input Transaksi", font=("Segoe UI", 22, "bold")).pack(pady=10)

        # Kalender (diperbesar lebih besar)
        self.calendar = Calendar(
            form_frame,
            selectmode="day",
            date_pattern="dd-mm-yyyy",
            font=("Segoe UI", 18),  # Font diperbesar
            width=500,  # Diperbesar dari 450
            height=300,  # Diperbesar dari 320
            background="#E3EEFF",
            headersbackground="#79AFFF",
            selectbackground="#4CAF50",
            normalbackground="#F2F7FF"
        )
        self.calendar.pack(pady=15)

        # Input keterangan
        self.ket_input = ctk.CTkEntry(form_frame, placeholder_text="Keterangan (contoh: Gaji, Beli Makanan)", height=40)
        self.ket_input.pack(fill="x", padx=20, pady=8)

        # Input nominal
        self.nom_input = ctk.CTkEntry(form_frame, placeholder_text="Nominal (angka saja)", height=40)
        self.nom_input.pack(fill="x", padx=20, pady=8)

        # Pilih tipe transaksi
        self.tipe_input = ctk.CTkComboBox(form_frame, values=["Pemasukan", "Pengeluaran"], height=40)
        self.tipe_input.set("Pemasukan")
        self.tipe_input.pack(padx=20, pady=8)

        # Tombol tambah transaksi
        ctk.CTkButton(form_frame, text="Tambah Transaksi", fg_color="#79AFFF", height=45, command=self.add_transaction).pack(padx=20, pady=10, fill="x")

        # Frame tabel transaksi
        table_frame = ctk.CTkFrame(self.content_frame, fg_color="#E3EEFF", corner_radius=16)
        table_frame.pack(fill="both", expand=True, padx=50, pady=30)

        # Scrollbar (vertikal + horizontal)
        scroll_y = ttk.Scrollbar(table_frame, orient="vertical")
        scroll_x = ttk.Scrollbar(table_frame, orient="horizontal")
        scroll_y.pack(side="right", fill="y")
        scroll_x.pack(side="bottom", fill="x")

        # Tabel transaksi
        self.trans_table = ttk.Treeview(
            table_frame,
            columns=("Tanggal", "Keterangan", "Nominal", "Tipe"),
            show="headings",
            yscrollcommand=scroll_y.set,
            xscrollcommand=scroll_x.set
        )
        scroll_y.config(command=self.trans_table.yview)
        scroll_x.config(command=self.trans_table.xview)

        # Konfigurasi kolom tabel (diperkecil untuk nominal dan keterangan)
        self.trans_table.heading("Tanggal", text="Tanggal")
        self.trans_table.heading("Keterangan", text="Keterangan")
        self.trans_table.heading("Nominal", text="Nominal")
        self.trans_table.heading("Tipe", text="Tipe")

        self.trans_table.column("Tanggal", width=700, anchor="center")
        self.trans_table.column("Keterangan", width=700, anchor="center")  # Diperkecil dari 500
        self.trans_table.column("Nominal", width=700, anchor="center")  # Diperkecil dari 250
        self.trans_table.column("Tipe", width=700, anchor="center")

        self.trans_table.pack(fill="both", expand=True, padx=10, pady=10)

        # Tampilkan transaksi yang sudah ada
        self.load_transactions_to_table()

    def add_transaction(self):
        # Ambil data dari input
        tanggal = self.calendar.get_date()
        keterangan = self.ket_input.get().strip()
        nominal = self.nom_input.get().strip()
        tipe = self.tipe_input.get()

        # Validasi input
        if not keterangan or not nominal:
            messagebox.showwarning("Peringatan", "Isi keterangan dan nominal!")
            return
        try:
            nominal = float(nominal)
            if nominal <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Error", "Nominal harus angka positif!")
            return

        # Tambah ke daftar dan tabel
        new_trans = [tanggal, keterangan, f"Rp {nominal:,.0f}", tipe]
        self.transactions.append(new_trans)
        self.trans_table.insert("", "end", values=new_trans)

        # Kosongkan input
        self.ket_input.delete(0, "end")
        self.nom_input.delete(0, "end")

    def load_transactions_to_table(self):
        # Hapus data tabel lama
        for item in self.trans_table.get_children():
            self.trans_table.delete(item)
        # Tambah data baru
        for trans in self.transactions:
            self.trans_table.insert("", "end", values=trans)

    def save_transaction_file(self):
        if not self.transactions:
            messagebox.showwarning("Peringatan", "Tidak ada transaksi untuk disimpan!")
            return
        save_transactions(self.username, self.transactions)
        messagebox.showinfo("Sukses", "Transaksi berhasil disimpan ke file!")

    def do_logout(self):
        self.destroy()
        app = LoginRegister()
        app.mainloop()

# ================= JALANKAN APLIKASI =================
if __name__ == "__main__":
    try:
        splash = SplashScreen()
        splash.mainloop()
    except Exception as e:
        messagebox.showerror("Error Fatal", f"Aplikasi gagal berjalan: {str(e)}")